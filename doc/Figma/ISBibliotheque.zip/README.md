
  # ISBibliotheque

  This is a code bundle for ISBibliotheque. The original project is available at https://www.figma.com/design/bzkq5nIFc8uMZU5GWfe2U3/ISBibliotheque.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  